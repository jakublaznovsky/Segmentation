Greetings!
Main program is located at ./Main
I would like to apologize for the over-complicated hierarchy since it is extracted from an independent project.
All the paths are relative, you should be able to run the program without any adaption to your own system.
Let me know if anything goes wrong.

Yours.
Pengwei
10/20/2015
